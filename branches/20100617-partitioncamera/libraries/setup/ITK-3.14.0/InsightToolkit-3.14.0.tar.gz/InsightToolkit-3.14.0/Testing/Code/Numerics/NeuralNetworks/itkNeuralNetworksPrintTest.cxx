/*=========================================================================

  Program:   Insight Segmentation & Registration Toolkit
  Module:    $RCSfile: itkNeuralNetworksPrintTest.cxx,v $
  Language:  C++
  Date:      $Date: 2005-08-02 19:20:55 $
  Version:   $Revision: 1.1 $

  Copyright (c) Insight Software Consortium. All rights reserved.
  See ITKCopyright.txt or http://www.itk.org/HTML/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even 
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR 
     PURPOSE.  See the above copyright notices for more information.

=========================================================================*/
#if defined(_MSC_VER)
#pragma warning ( disable : 4786 )
#endif


int itkNeuralNetworksPrintTest(int , char* [])
{

// itk::BlobSpatialObject<3>::Pointer BlobSpatialObjectObj =
//    itk::BlobSpatialObject<3>::New();
//  std::cout << "----------BlobSpatialObject " << BlobSpatialObjectObj;

  return 0;
}
