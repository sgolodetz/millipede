/*=========================================================================
                                                                                
  Program:   gdcm
  Module:    $RCSfile: vtkGdcmWriter.h,v $
  Language:  C++
  Date:      $Date: 2006/04/21 14:11:54 $
  Version:   $Revision: 1.6.2.2 $
                                                                                
  Copyright (c) CREATIS (Centre de Recherche et d'Applications en Traitement de
  l'Image). All rights reserved. See Doc/License.txt or
  http://www.creatis.insa-lyon.fr/Public/Gdcm/License.html for details.
                                                                                
     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notices for more information.
                                                                                
=========================================================================*/
                                                                                
#ifndef __vtkGdcmWriter_h
#define __vtkGdcmWriter_h

#include "gdcmCommon.h" // To avoid warnings concerning the std
#include <vtkImageWriter.h>

//-----------------------------------------------------------------------------
#define VTK_GDCM_WRITE_TYPE_EXPLICIT_VR 1
#define VTK_GDCM_WRITE_TYPE_IMPLICIT_VR 2
#define VTK_GDCM_WRITE_TYPE_ACR         3
#define VTK_GDCM_WRITE_TYPE_ACR_LIBIDO  4

//-----------------------------------------------------------------------------
class vtkLookupTable;
class vtkMedicalImageProperties;
class VTK_EXPORT vtkGdcmWriter : public vtkImageWriter
{
public:
   static vtkGdcmWriter *New();
   vtkTypeRevisionMacro(vtkGdcmWriter, vtkImageWriter);

   void PrintSelf(ostream &os, vtkIndent indent);

   virtual void SetLookupTable(vtkLookupTable*);
   vtkGetObjectMacro(LookupTable, vtkLookupTable);

   void SetWriteTypeToDcmImplVR(){SetWriteType(VTK_GDCM_WRITE_TYPE_EXPLICIT_VR);};
   void SetWriteTypeToDcmExplVR(){SetWriteType(VTK_GDCM_WRITE_TYPE_IMPLICIT_VR);};
   void SetWriteTypeToAcr()      {SetWriteType(VTK_GDCM_WRITE_TYPE_ACR);        };
   void SetWriteTypeToAcrLibido(){SetWriteType(VTK_GDCM_WRITE_TYPE_ACR_LIBIDO); };
   vtkSetMacro(WriteType, int);
   vtkGetMacro(WriteType, int);
   const char *GetWriteTypeAsString();

   // Description:
   // To pass in some extra information from a VTK context a user can pass a
   // vtkMedicalImageProperties object
#if (VTK_MAJOR_VERSION >= 5)
   void SetMedicalImageProperties(vtkMedicalImageProperties*);
#else
   void SetMedicalImageProperties(vtkMedicalImageProperties*) {}
#endif

protected:
   vtkGdcmWriter();
   ~vtkGdcmWriter();

  virtual void RecursiveWrite(int axis, vtkImageData *image, ofstream *file);
  virtual void RecursiveWrite(int axis, vtkImageData *image, 
                              vtkImageData *cache, ofstream *file);
  void WriteDcmFile(char *fileName, vtkImageData *image);

private:
// Variables
   vtkLookupTable *LookupTable;
   vtkMedicalImageProperties *MedicalImageProperties;
   int WriteType;
};

//-----------------------------------------------------------------------------
#endif
