import wxPython.wx
import foo
foo.MyWrappedFunction()
